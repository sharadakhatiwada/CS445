let notSure: any = 4;
notSure = 'Maybe a string instead';
notSure = false;
console.log(notSure);